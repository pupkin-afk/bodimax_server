-- AlterEnum
ALTER TYPE "NotifcationKind" ADD VALUE 'Welcome';
