-- AlterTable
ALTER TABLE "User" ALTER COLUMN "coverUrl" SET DEFAULT '/covers/no-cover.png';
