-- CreateIndex
CREATE INDEX "Notification_userId_id_kind_idx" ON "Notification"("userId", "id", "kind");
