-- AlterTable
ALTER TABLE "User" ADD COLUMN     "email" TEXT;
